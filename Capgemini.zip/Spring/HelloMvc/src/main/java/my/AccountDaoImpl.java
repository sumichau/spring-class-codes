package my;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class AccountDaoImpl implements AccountDao {

	@PersistenceContext
	EntityManager em;
	
	
	
	@Override
	public void save(Employee e) {
		// TODO Auto-generated method stub
		em.persist(e);
	}



	@Override
	public Employee read(int id) {
		// TODO Auto-generated method stub
		return em.find(Employee.class,id);
	}



	@Override
	public Employee update(int id, String name) {
		// TODO Auto-generated method stub
		Employee e= em.find(Employee.class, id);
		e.setName(name);
		return e;
		
	}



	@Override
	public int delete(int id) {
		// TODO Auto-generated method stub
		Employee e= em.find(Employee.class, id);
		em.remove(e);
		return id;
	}

}
