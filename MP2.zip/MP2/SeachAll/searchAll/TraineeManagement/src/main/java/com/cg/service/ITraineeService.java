package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainee;

public interface ITraineeService {

	public String addTrainee(@Valid Trainee t, BindingResult result);

//	public List<Trainee> getAllTrainee();
//
//	public Trainee searchTrainee(int id);
}
