package com.cg.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import com.cg.bean.Trainee;
import com.cg.dao.ITraineeDao;

public class TraineeServiceImpl implements ITraineeService {

	ITraineeDao traineeDao;

	// SERVICE METHOD TO ADD (BUSINESS LOGIC)
	@Override
	public String addTrainee(@Valid Trainee t, BindingResult result) {
		if (result.hasErrors()) {
			return "ERROR";
		}
		traineeDao.save(t);
		return "SUCCESS";
	}

//	// SERVICE METHOD TO RETRIEVE ALL (BUSINESS LOGIC)
//	@Override
//	public List<Trainee> getAllTrainee() {
//		return traineeDao.getAll();
//	}
//
//	// gs
	public ITraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(ITraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

//	// SERVICE METHOD TO RETRIEVE (BUSINESS LOGIC)
//	@Override
//	public Trainee searchTrainee(int id) {
//		if (id == 0) {
//			return null;
//		}
//		Trainee tr = traineeDao.search(id);
//		return tr;
//	}



}
