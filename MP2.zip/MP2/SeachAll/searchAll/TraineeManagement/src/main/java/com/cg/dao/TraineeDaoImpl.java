package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.transaction.annotation.Transactional;
import com.cg.bean.Trainee;

public class TraineeDaoImpl implements ITraineeDao {
	@PersistenceContext
	EntityManager em;
	
	//To Add data
	@Transactional
	@Override
	public void save(Trainee t) {
		em.persist(t);
	}
	
//	//To Search data
//		@Override
//		public Trainee search(int id) {
//			Trainee t = em.find(Trainee.class, id);
//			return t;
//		}
//	
//	//To get all trainee
//	@Override
//	public List<Trainee> getAll() {
//
//		List<Trainee> listTrainee = em.createQuery("SELECT t FROM Trainee t").getResultList();
//
//		if (listTrainee == null) {
//			System.out.println("No Trainee found . ");
//		} else {
//			for (Trainee trainee : listTrainee) {
//				System.out.println(trainee);
//			}
//		}
//
//		return listTrainee;
//
//	}

}
