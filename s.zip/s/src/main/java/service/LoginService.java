package service;

import org.springframework.validation.BindingResult;

import ui.Student;

public interface LoginService {
	public String newRecord(Student e, BindingResult result);
	

}
