package service;

import javax.validation.Valid;

import org.springframework.validation.BindingResult;

import dao.LoginDao;
import ui.Student;

public class LoginServiceImpl implements LoginService {

	
	LoginDao loginDao;
	
	
	
	
	public LoginServiceImpl(LoginDao loginDao) {
		super();
		this.loginDao = loginDao;
	}




	@Override
	public String newRecord(  Student e, BindingResult result) {
		// TODO Auto-generated method stub
		if(result.hasErrors()) {
			return "ERROR";
			
		}
		loginDao.save(e);
		return "SUCCESS";

	}




}
