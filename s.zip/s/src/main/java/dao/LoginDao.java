package dao;

import org.springframework.transaction.annotation.Transactional;


import ui.Student;

public interface LoginDao {
	//@Transactional
	public void save(Student e);
	


}
