package dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.transaction.annotation.Transactional;

import ui.Student;
@Transactional
public class LoginDaoImpl implements LoginDao {

	
	@PersistenceContext
	EntityManager em;

	@Override
	public void save(Student e) {
		// TODO Auto-generated method stub
		em.persist(e);
	}

}
