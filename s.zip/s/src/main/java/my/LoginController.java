package my;

import java.util.ArrayList;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import service.LoginServiceImpl;
import ui.Student;

@Controller
public class LoginController {

	
	@Autowired
	LoginServiceImpl impl;
	
	@RequestMapping(method=RequestMethod.GET, path="/page")
	public ModelAndView sayHello(@ModelAttribute("e") Student e) {
	ModelAndView mv = new ModelAndView();
		
		ArrayList<String> al=new ArrayList<>();
		al.add("India");
		al.add("England");
		al.add("Australia");
		al.add("Canada");
		mv.addObject("list",al);
		mv.setViewName("Hello");
		
		return mv;
	}
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST, path="/getrecord")
	public ModelAndView newEmployee(@ModelAttribute("e") @Valid Student e, BindingResult result) {
		
		
		ModelAndView mv = new ModelAndView();
		
		ArrayList<String> al=new ArrayList<>();
		al.add("India");
		al.add("England");
		al.add("Australia");
		al.add("Canada");
	
		mv.addObject("list",al);
		mv.setViewName("Hello");
		
		String name = impl.newRecord(e, result);
		if(result.hasErrors()) {
			return mv;
		}
		mv.setViewName("record");
		mv.addObject("key", e.getId());
		return mv;
	}
	
}
